# Librería de Números Complejos en Python

Implementación de operaciones con números complejos **sin usar el tipo complex de Python**.

## Funcionalidades
- Suma
- Resta
- Producto
- División
- Módulo
- Conjugado
- Conversión entre cartesiano ↔ polar
- Fase

## Ejecución de pruebas
```bash
python -m unittest discover tests
